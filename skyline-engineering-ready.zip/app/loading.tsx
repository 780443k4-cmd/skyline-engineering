export default function Loading() {
  return (
    <div className="h-[60vh] flex items-center justify-center">
      <div className="w-8 h-8 border border-line border-t-skyline rounded-full animate-spin" />
    </div>
  );
}
